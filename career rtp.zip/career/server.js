const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');
const nodemailer = require('nodemailer');
const db = require('./db'); // MySQL connection file

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// Session setup
app.use(session({
  secret: 'career-guidance-secret',
  resave: false,
  saveUninitialized: true
}));

// Serve static pages
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public/index.html')));
app.get('/login.html', (req, res) => res.sendFile(path.join(__dirname, 'public/login.html')));
app.get('/signup.html', (req, res) => res.sendFile(path.join(__dirname, 'public/signup.html')));
app.get('/qualification.html', (req, res) => {
  if (!req.session.user) return res.redirect('/login.html');
  res.sendFile(path.join(__dirname, 'public/qualification.html'));
});
app.get('/logout.html', (req, res) => {
  if (!req.session.user) return res.redirect('/login.html');
  res.sendFile(path.join(__dirname, 'public/logout.html'));
});

// Signup
app.post('/signup', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.send('All fields are required');
  }

  const checkQuery = 'SELECT * FROM users WHERE name = ? OR email = ?';
  db.query(checkQuery, [name, email], (err, results) => {
    if (err) {
      console.error('Signup Check Error:', err);
      return res.send('Error during signup');
    }

    if (results.length > 0) {
      return res.send('Account already exists with the same name or email. Please log in.');
    }

    const insertQuery = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
    db.query(insertQuery, [name, email, password], (err, result) => {
      if (err) {
        console.error('Signup Error:', err);
        return res.send('Error registering user');
      }
      console.log('✅ User registered:', result);
      req.session.user = { name, email };
      res.redirect('/qualification.html');
    });
  });
});

// =====================
// LOGIN WITH OTP LOGIC
// =====================
app.post('/login', (req, res) => {
  // Use either 'name' (first step) or 'otp_name' (OTP step)
  const name = req.body.name || req.body.otp_name;
  const { password, otp } = req.body;

  // Step 1: Username/Password check, generate OTP
  if (!otp) {
    if (!name || !password) {
      return res.send('Both name and password are required');
    }

    const query = 'SELECT * FROM users WHERE name = ? AND password = ?';
    db.query(query, [name, password], (err, results) => {
      if (err) {
        console.error('Login Error:', err);
        return res.send('Login failed');
      }

      if (results.length > 0) {
        // Generate OTP and store in session
        const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
        req.session.tempUser = { name: results[0].name, email: results[0].email };
        req.session.otp = generatedOtp;

        // For demo: display OTP on page (in production, send via email/SMS)
        res.redirect(`/login.html?showOtp=1&otp=${generatedOtp}&name=${encodeURIComponent(name)}`);
      } else {
        res.send('Invalid credentials');
      }
    });
  } else {
    // Step 2: OTP verification
    console.log('OTP from user:', otp);
    console.log('Session OTP:', req.session.otp);
    console.log('Session tempUser:', req.session.tempUser);

    if (!req.session.tempUser || !req.session.otp) {
      return res.send('Session expired. Please try again.');
    }
    if (otp === req.session.otp) {
      // OTP correct, log user in
      req.session.user = req.session.tempUser;
      delete req.session.tempUser;
      delete req.session.otp;
      res.redirect('/qualification.html');
    } else {
      res.send('Incorrect OTP. Please try again.');
    }
  }
});

// Contact form
app.post('/contact', (req, res) => {
  const { name, email, message } = req.body;

  if (!name || !email || !message) {
    return res.send('All fields are required');
  }

  const query = 'INSERT INTO contact (name, email, message) VALUES (?, ?, ?)';
  db.query(query, [name, email, message], (err) => {
    if (err) {
      console.error('DB Error:', err);
      return res.send('Error saving message');
    }

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'anvithamanchala2005@gmail.com',
        pass: 'dkvkwmaldpsltzap',
      },
    });

    const mailOptions = {
      from: email,
      to: 'anvithamanchala2005@gmail.com',
      subject: 'New Contact Message from Career Guidance Portal',
      text: `Name: ${name}\nEmail: ${email}\nMessage:\n${message}`,
    };

    transporter.sendMail(mailOptions, (err, info) => {
      if (err) {
        console.error('Email Error:', err);
        return res.send('Message saved, but email not sent');
      }
      console.log('✅ Email sent:', info.response);
      res.redirect('/thankyou.html');
    });
  });
});

// Logout (deletes user from DB + session destroy)
app.post('/logout', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login.html');
  }

  const sessionUser = req.session.user;
  const postedName = req.body.name;

  if (postedName !== sessionUser.name) {
    return res.send('Error: Entered username does not match the logged-in user.');
  }

  const deleteQuery = 'DELETE FROM users WHERE name = ? AND email = ?';
  db.query(deleteQuery, [sessionUser.name, sessionUser.email], (err, result) => {
    if (err) {
      console.error('❌ Error deleting user:', err);
      return res.status(500).send('Failed to delete user');
    }

    req.session.destroy(err => {
      if (err) {
        return res.status(500).send('Error ending session');
      }
      res.clearCookie('connect.sid');
      console.log(`🗑️ User deleted: ${sessionUser.name}`);
      res.redirect('/thankyou.html');
    });
  });
});




// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
